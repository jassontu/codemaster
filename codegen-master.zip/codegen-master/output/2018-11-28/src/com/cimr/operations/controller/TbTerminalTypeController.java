package com.cimr.operations.controller;

import com.cimr.comm.aop.AccessLog;
import com.cimr.comm.enums.SysEnums;
import com.cimr.operations.dto.TbTerminalTypeDto;
import com.cimr.operations.model.TbTerminalType;
import com.cimr.operations.service.TbTerminalTypeService;
import com.cimr.sysmanage.dto.HttpResult;
import com.cimr.sysmanage.dto.LayuiTableData;
import com.cimr.sysmanage.dto.SelectDto;
import com.cimr.util.Assist;
import com.cimr.util.LogUtil;
import com.cimr.util.PageData;
import com.cimr.util.StringUtil;
import com.cimr.comm.util.IdUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

/**
 * customer模块控制器
 * @author suhuanzhao 2018-11-28 10:57:30
 */
@Controller
@RequestMapping("/customer")
public class TbTerminalTypeController {

    @Autowired
    private TbTerminalTypeService customerService;

    private static final Logger logger = LoggerFactory.getLogger(TbTerminalTypeController.class);


    /**
     * customer列表页面路由跳转
     *
     * @param request
     * @return
     */
    @RequestMapping({"nav/list"})
    @AccessLog(methods = "index", module = "customer")
    public ModelAndView index(HttpServletRequest request) {
        ModelAndView modelAndView = new ModelAndView("operations/TbTerminalTypeList");
        return modelAndView;
    }

    /**
     * customer表单页面路由跳转
     *
     * @param request
     * @param id
     * @return
     */
    @RequestMapping({"nav/form"})
    @AccessLog(methods = "form", module = "customer")
    public ModelAndView form(HttpServletRequest request, String id) {
        ModelAndView modelAndView = new ModelAndView("operations/TbTerminalTypeForm");
        //处理空id的情况
        modelAndView.addObject("id", StringUtil.empty(id) ? "" : id);
        return modelAndView;
    }

    /**
     * customer列表分页
     *
     * @param page
     * @param limit
     * @return
     */
    @RequestMapping({"/ajax/selectPage"})
    @ResponseBody
    @AccessLog(methods = "selectTbTerminalTypePage", module = "customer")
    public LayuiTableData selectTbTerminalTypePage(TbTerminalTypeDto customerDto, Integer page, Integer limit, HttpServletRequest request) {
        LayuiTableData result = new LayuiTableData();
        //分页查询
        try {
            Assist assist = new Assist();
            assist.setRequires(Assist.andEq("remark",customerDto.getRemark()));
            assist.setRequires(Assist.andEq("status",customerDto.getStatus()));
            assist.setRequires(Assist.andEq("type",customerDto.getType()));
            assist.setRequires(Assist.andEq("type_name",customerDto.getTypeName()));
            assist.setRequires(Assist.andEq("type_parm",customerDto.getTypeParm()));
            PageData<TbTerminalType> pagaData = customerService.selectPageCommon(assist, page, limit);
            //表示请求成功,layui的列表插件会判断这个code
            result.setCode(0);
            result.setCount(pagaData.getCount());
            result.setData(pagaData.getList());
        } catch (Exception e) {
            LogUtil.printStackTraceToLog(request,e, logger, SysEnums.HTTP_500,null);
            result.setCode(SysEnums.HTTP_500.getCode());
        }
        return result;
    }

    /**
     * customer保存或者更新
     *
     * @param session
     * @return
     */
    @RequestMapping({"/ajax/save"})
    @ResponseBody
    @AccessLog(methods = "saveTbTerminalType", module = "customer")
    public HttpResult saveTbTerminalType(@Valid TbTerminalTypeDto customerDto, Errors validResult, HttpServletRequest request, HttpSession session) {
        HttpResult result = new HttpResult(true, "保存成功");
        //表单校验
        if (validResult.hasErrors()) {
            for (FieldError error : validResult.getFieldErrors()) {
                result.setSuccess(false);
                result.setCode(SysEnums.ERROR_FORM_VALIDATE.getCode());
                result.setError(error.getDefaultMessage());
                return result;
            }
        }
        try {
            if (StringUtil.empty(customerDto.getId())) {
                //新增
                customerDto.setId(IdUtil.getId());
                result = customerService.insertNonEmptyObjCommon(customerDto);
            } else {
                //更新
                result = customerService.updateNonEmptyObjByIdCommon(customerDto);
            }
        } catch (Exception e) {
            result.setSuccess(false);
            result.setCode(SysEnums.HTTP_500.getCode());
            result.setError("操作失败，系统出现异常！异常代码:" + SysEnums.HTTP_500.getCode());
            LogUtil.printStackTraceToLog(request,e, logger, SysEnums.HTTP_500,null);
        }
        return result;
    }

    /**
     * customer删除
     *
     * @param id
     * @return
     */
    @RequestMapping({"/ajax/delete"})
    @ResponseBody
    @AccessLog(methods = "deleteTbTerminalType", module = "customer")
    public HttpResult deleteTbTerminalType(@RequestParam(required = true) String id, HttpServletRequest request) {
        HttpResult result = new HttpResult(true, "删除成功");
        try {
            //删除(逻辑删除)
            TbTerminalType customer = new TbTerminalType();
            customer.setId(id);
            result = customerService.deleteObjByIdLogicCommon(customer);
        } catch (Exception e) {
            result.setSuccess(false);
            result.setCode(SysEnums.HTTP_500.getCode());
            result.setError("操作失败，系统出现异常！异常代码:" + SysEnums.HTTP_500.getCode());
            LogUtil.printStackTraceToLog(request,e, logger, SysEnums.HTTP_500,null);
        }
        return result;
    }

    /**
     * customer获取单个对象
     *
     * @param id
     * @return
     */
    @RequestMapping({"/ajax/selectTbTerminalTypeInfo"})
    @ResponseBody
    @AccessLog(methods = "selectTbTerminalTypeInfo", module = "customer")
    public HttpResult selectTbTerminalTypeInfo(@RequestParam(required = true) String id, HttpServletRequest request) {
        HttpResult result = new HttpResult(true, "获取成功");
        try {
            TbTerminalType customer = customerService.selectObjByIdCommon(id);
            result.setData(customer);
        } catch (Exception e) {
            result.setSuccess(false);
            result.setCode(SysEnums.HTTP_500.getCode());
            result.setError("操作失败，系统出现异常！异常代码:" + SysEnums.HTTP_500.getCode());
            LogUtil.printStackTraceToLog(request,e, logger, SysEnums.HTTP_500,null);
        }
        return result;
    }

    /**
     * customer获取列表
     *
     * @return
     */
    @ResponseBody
    @RequestMapping("/ajax/selectTbTerminalTypeList")
    @AccessLog(methods = "selectTbTerminalTypeList", module = "customer")
    public HttpResult selectTbTerminalTypeList(TbTerminalTypeDto customerDto, HttpServletRequest request) {
        HttpResult result = new HttpResult(true, "");
        try {
            Assist assist = new Assist();
            assist.setRequires(Assist.andEq("remark",customerDto.getRemark()));
            assist.setRequires(Assist.andEq("status",customerDto.getStatus()));
            assist.setRequires(Assist.andEq("type",customerDto.getType()));
            assist.setRequires(Assist.andEq("type_name",customerDto.getTypeName()));
            assist.setRequires(Assist.andEq("type_parm",customerDto.getTypeParm()));
            List<TbTerminalType> customerList = customerService.selectListCommon(assist);
            result.setData(customerList);
        } catch (Exception e) {
            result.setSuccess(false);
            result.setCode(SysEnums.HTTP_500.getCode());
            result.setError("操作失败，系统出现异常！异常代码:" + SysEnums.HTTP_500.getCode());
            LogUtil.printStackTraceToLog(request,e, logger, SysEnums.HTTP_500,null);
        }
        return result;
    }

    /**
     * customer适配前台下拉框数据查询
     *
     * @param value
     * @return
     */
    @RequestMapping("/ajax/selectTbTerminalTypeSelectData")
    @ResponseBody
    @AccessLog(methods = "selectTbTerminalTypeSelectData", module = "customer")
    public HttpResult selectTbTerminalTypeSelectData(String value, String title, HttpServletRequest request) {
        HttpResult result = new HttpResult(true, "");
        //下拉框数据对象集合
        List<SelectDto<String, String>> selectDtoList = new ArrayList<>();
        title = title == null ? "请选择":title;
        selectDtoList.add(new SelectDto<>(title, ""));
        //查询数据
        List<TbTerminalType> customerList = customerService.selectListCommon(null);
        try {
            SelectDto<String, String> selectDto;
            for (TbTerminalType customer : customerList) {
                selectDto = new SelectDto<>(customer.getRemark(), customer.getId());
                //回显选中
                if (customer.getId().equals(value)) {
                    selectDto.setSelected(true);
                }
                selectDtoList.add(selectDto);
            }
            result.setData(selectDtoList);
        } catch (Exception e) {
            result.setSuccess(false);
            result.setCode(SysEnums.HTTP_500.getCode());
            result.setError("操作失败，系统出现异常！异常代码:" + SysEnums.HTTP_500.getCode());
            LogUtil.printStackTraceToLog(request,e, logger, SysEnums.HTTP_500,null);
        }
        return result;
    }

}