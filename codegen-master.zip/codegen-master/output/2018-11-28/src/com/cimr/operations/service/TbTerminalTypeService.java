package com.cimr.operations.service;

import com.cimr.comm.base.IotBaseService;
import com.cimr.operations.model.TbTerminalType;
/**
 * 的相关业务处理接口
 * @author suhuanzhao 2018-11-28 10:57:30
 */
public interface TbTerminalTypeService extends IotBaseService<TbTerminalType,String> {
    
	//TODO 在此添加其他业务处理的方法
}