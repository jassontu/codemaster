package com.cimr.operations.dao;

import com.cimr.comm.base.IotBaseDao;
import com.cimr.operations.model.TbTerminalType;


/**
 * 的数据访问层
 * @author suhuanzhao 2018-11-28 10:57:30
 */
public interface TbTerminalTypeDao extends IotBaseDao<TbTerminalType,String> {
    
	//TODO 在此添加其他数据访问的方法
}