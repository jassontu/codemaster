package com.cimr.operations.model;

/**
 * JAVA实体类TbTerminalType
 * @author suhuanzhao 2018-11-28 10:57:30
 */
import com.cimr.comm.base.BaseEntity;
import org.hibernate.validator.constraints.NotEmpty;
import java.util.Date;

public class TbTerminalType extends BaseEntity{
    
    public TbTerminalType() {
        super();
    }
	

    private String id;


    /**
    * 标志,不能为空
    */
    @NotEmpty(message = "标志不能为空")
    private String remark;

    private Integer status;


    /**
    * 终端型号 ,不能为空
    */
    @NotEmpty(message = "终端型号 不能为空")
    private String type;


    /**
    * 类型名称 ,不能为空
    */
    @NotEmpty(message = "类型名称 不能为空")
    private String typeName;


    /**
    * 型号参数 ,不能为空
    */
    @NotEmpty(message = "型号参数 不能为空")
    private String typeParm;
    
    public void setId(String id) {
        this.id = id;
    }
    
    public String getId() {
        return this.id;
    }
    public void setRemark(String remark) {
        this.remark = remark;
    }
    
    public String getRemark() {
        return this.remark;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    
    public Integer getStatus() {
        return this.status;
    }
    public void setType(String type) {
        this.type = type;
    }
    
    public String getType() {
        return this.type;
    }
    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }
    
    public String getTypeName() {
        return this.typeName;
    }
    public void setTypeParm(String typeParm) {
        this.typeParm = typeParm;
    }
    
    public String getTypeParm() {
        return this.typeParm;
    }
}