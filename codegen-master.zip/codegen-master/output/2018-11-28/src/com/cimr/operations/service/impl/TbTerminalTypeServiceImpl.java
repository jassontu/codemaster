package com.cimr.operations.service.impl;

import com.cimr.comm.base.IotBaseDao;
import com.cimr.comm.base.IotBaseServiceImpl;
import com.cimr.operations.model.TbTerminalType;
import com.cimr.operations.dao.TbTerminalTypeDao;
import com.cimr.operations.service.TbTerminalTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
 * 类TbTerminalTypeServiceImpl的实现描述：
 * @author suhuanzhao 2018-11-28 10:57:30
 */
@Service
public class TbTerminalTypeServiceImpl extends IotBaseServiceImpl<TbTerminalType,String> implements TbTerminalTypeService  {
    
	@Autowired
    private TbTerminalTypeDao   tbTerminalTypeDao;

    @Override
    protected IotBaseDao<TbTerminalType, String> getEntityDao() {
        return tbTerminalTypeDao;
    }
}