package com.cimr.operations.dto;

/**
 * TbTerminalTypeDto类
 * @author suhuanzhao 2018-11-28 10:57:30
 */

import com.cimr.operations.model.TbTerminalType;

public class TbTerminalTypeDto extends TbTerminalType{
    
    public TbTerminalTypeDto() {
        super();
    }

    public TbTerminalTypeDto(TbTerminalType customer) {
        setId(customer.getId());
        setCreateBy(customer.getCreateBy());
        setCreateTime(customer.getCreateTime());
        setDelFlag(customer.getDelFlag());
        setRemark(customer.getRemark());
        setUpdateBy(customer.getUpdateBy());
        setUpdateTime(customer.getUpdateTime());
        setStatus(customer.getStatus());
        setType(customer.getType());
        setTypeName(customer.getTypeName());
        setTypeParm(customer.getTypeParm());
    }
	
    //创建者名称
    private String createByName;
    //更新者名称
    private String updateByName;
    //格式化创建时间
    private String createTimeStr;
    //格式化更新时间
    private String updateTimeStr;
    
    public String getCreateByName() {
        return createByName;
    }

    public void setCreateByName(String createByName) {
        this.createByName = createByName;
    }

    public String getUpdateByName() {
        return updateByName;
    }

    public void setUpdateByName(String updateByName) {
        this.updateByName = updateByName;
    }

    public String getCreateTimeStr() {
        return createTimeStr;
    }

    public void setCreateTimeStr(String createTimeStr) {
        this.createTimeStr = createTimeStr;
    }

    public String getUpdateTimeStr() {
        return updateTimeStr;
    }

    public void setUpdateTimeStr(String updateTimeStr) {
        this.updateTimeStr = updateTimeStr;
    }

}