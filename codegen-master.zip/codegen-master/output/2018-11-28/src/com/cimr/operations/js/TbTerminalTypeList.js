var customerList = {};

//Action类是一些页面上的动作函数
customerList.action = {
    //页面初始化函数
    initBody: function () {
        customerList.interface.initTablePage();
    },
    /**
     * 事件绑定
     */
    bindEvent: function () {
        $("#addBtn").click(function () {
            customerList.action.toFormPage();
            return false;
        });
        $(".close").click(function () {
            this.remove();
        })
    },
    /**
     * 列表页插件初始化
     */
    initPluginsAndEvents:function () {
        customerList.action.bindEvent();
    },

    /**
     * 跳转到表单页面
     * @param id
     */
    toFormPage:function (id) {
        if ($.isEmpty(id)){
            window.location.href = AppCommon.url.getBaseURL() + "/customer/nav/form";
        }else {
            window.location.href = AppCommon.url.getBaseURL() + "/customer/nav/form?id="+id;
        }
    },
    /**
     * 删除
     * @param id
     */
    deleteTbTerminalType: function (id) {
        var params = {
            'id': id
        };
        //注意每一个ajax请求的onSuccess处理方法需要处理请求失败的情况,打印出失败信息
        var onSuccess = function (resultData) {
            layer.closeAll('loading');
            if (resultData.success) {
                layer.msg("删除成功！", {icon: 1});
                customerList.data.tableIns.reload({
                    page: {curr: 1}
                });
            }else {
                layer.msg(resultData.error, {icon: 5});
            }
        };
        layer.load();
        AppCommon.ajax.execute({
            'url': AppCommon.url.getBaseURL() + '/customer/ajax/delete',
            'data': params,
            'success': onSuccess,
            'error':function(){},
        });
    },

};

//interface类是一些页面渲染函数
customerList.interface ={
    //渲染列表页面
    initTablePage: function () {
        var html = template("customerList_template");
        $(".customerList_box").html(html);
        //绑定事件和插件
        customerList.action.initPluginsAndEvents();
        //layui列表插件
        layer.load();
        layui.use(['table', 'form'], function () {
            var table = layui.table;
            //执行表格渲染
            var tableIns = table.render({
                //height: 476,
                url: AppCommon.url.getBaseURL() + '/customer/ajax/selectPage',
                elem: "#tb_list",
                page: true,
                limit: 10,
                loading: true,
                id: 'id',
                cols: [[
                    //自动生成需要展示的列start
                    {
                        field: 'remark',
                        title: '标志',
                        align: 'left'
                    },
                    {
                        field: 'status',
                        title: '状态 ',
                        align: 'left'
                    },
                    {
                        field: 'type',
                        title: '终端型号 ',
                        align: 'left'
                    },
                    {
                        field: 'typeName',
                        title: '类型名称 ',
                        align: 'left'
                    },
                    {
                        field: 'typeParm',
                        title: '型号参数 ',
                        align: 'left'
                    },
                //自动生成需要展示的列end
                    //后台已经默认把createTime和updateTime格式化了,只需要获取createTimeStr和updateTimeStr即可
                    {
                        field: 'createTimeStr',
                        title: '创建时间↓',
                        align: 'left'
                    },
                    {
                        field: 'opration',
                        //width: 140,
                        title: '操作',
                        align: 'center',
                        toolbar: '#toolbar'
                    }
                ]],
                //表格加载完后的回调
                done:function(res, curr, count) {
                    layer.closeAll('loading');
                }
            });
            customerList.data.tableIns = tableIns;
            //表格里的按钮的事件监听
            table.on('tool(tb_list)', function (obj) {
                //获取当前选中行
                var rowData = obj.data;
                var layEvent = obj.event;
                if (layEvent === 'editBtn') {
                    customerList.action.toFormPage(rowData.id);
                } else if (layEvent === 'deleteBtn') {
                    layer.confirm('确定要进行删除吗？', {icon: 3, title: '提示'}, function (index) {
                        customerList.action.deleteTbTerminalType(rowData.id);
                        layer.close(index);
                    }, function (index) {
                        layer.close(index);
                    });
                }
            });
            // 列表查询
            var form = layui.form;
            form.render(null, 'searchForm');
            form.on('submit(searchBtn)', function (data) {
                //查询参数
                var postData = {
                remark: $.trim(data.field.searchRemark),
                status: $.trim(data.field.searchStatus),
                type: $.trim(data.field.searchType),
                typeName: $.trim(data.field.searchTypeName),
                typeParm: $.trim(data.field.searchTypeParm),
                };
                //查询完成后跳转到第一页
                tableIns.reload({
                    page: {curr: 1},
                    where: postData
                });
                return false;
            });
        });

    },
};
//页面里的一些全局变量
customerList.data ={

};
//开始渲染页面
customerList.event ={
    'isReaded': false,
    onReady: function () {
        customerList.action.initBody();
    }
}
//页面加载完后执行
AppCommon.action.ready(function () {
    if (!customerList.event.isReaded) {
        customerList.event.isReaded = true;
        customerList.event.onReady();
    }
});